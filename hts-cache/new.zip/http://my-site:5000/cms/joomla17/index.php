<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
   <base href="http://my-site:5000/cms/joomla17/index.php" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="keywords" content="game, rendering, graphics, gpu" />
  <meta name="description" content="Game, Graphic programming, Guitar and Cooking " />
  <meta name="generator" content="Joomla! - Open Source Content Management" />
  <title>Home</title>
  <link href="/cms/joomla17/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="/cms/joomla17/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link href="http://my-site:5000/cms/joomla17/index.php/component/search/?format=opensearch" rel="search" title="Search Example Online Porforlio 2012 - Aikdev.co.uk" type="application/opensearchdescription+xml" />
  <link rel="stylesheet" href="/cms/joomla17/modules/mod_featcats/mod_featcats.css" type="text/css" />
  <link rel="stylesheet" href="/cms/joomla17/modules/mod_lofarticlesslideshow/assets/jstyle.css" type="text/css" />
  <style type="text/css">
.random_image_extended {text-align: center !important; margin: 10px 0 !important;}
.random_image_extended_small {text-align: right !important; font-size: 0.85em !important; margin-top: 15px !important;}

  </style>
  <script src="/cms/joomla17/media/system/js/mootools-core.js" type="text/javascript"></script>
  <script src="/cms/joomla17/media/system/js/core.js" type="text/javascript"></script>
  <script src="/cms/joomla17/media/system/js/caption.js" type="text/javascript"></script>
  <script src="/cms/joomla17/modules/mod_lofarticlesslideshow/assets/jscript.js" type="text/javascript"></script>
  <script type="text/javascript">
window.addEvent('load', function() {
				new JCaption('img.caption');
			});
  </script>
  <link rel="stylesheet" href="/cms/joomla17/modules/mod_random_image_extended/shadowbox/shadowbox.css" type="text/css" media="screen" />
<script type="text/javascript" src="/cms/joomla17/modules/mod_random_image_extended/shadowbox/shadowbox.js"></script>
<script type="text/javascript">Shadowbox.init();</script>

 <link rel="stylesheet" href="/cms/joomla17/templates/system/css/system.css" type="text/css" />
 <link rel="stylesheet" href="/cms/joomla17/templates/system/css/general.css" type="text/css" />
 <link rel="stylesheet" type="text/css" href="/cms/joomla17/templates/tpl_home/css/template.css" media="screen" />
 <!--[if IE 6]><link rel="stylesheet" href="/cms/joomla17/templates/tpl_home/css/template.ie6.css" type="text/css" media="screen" /><![endif]-->
 <!--[if IE 7]><link rel="stylesheet" href="/cms/joomla17/templates/tpl_home/css/template.ie7.css" type="text/css" media="screen" /><![endif]-->
 <script type="text/javascript">if ('undefined' != typeof jQuery) document._artxJQueryBackup = jQuery;</script>
 <script type="text/javascript" src="/cms/joomla17/templates/tpl_home/jquery.js"></script>
 <script type="text/javascript">jQuery.noConflict();</script>
 <script type="text/javascript" src="/cms/joomla17/templates/tpl_home/script.js"></script>
 <script type="text/javascript">if (document._artxJQueryBackup) jQuery = document._artxJQueryBackup;</script>
</head>
<body class="art-j16">
<div id="art-page-background-middle-texture">
<div id="art-page-background-glare">
    <div id="art-page-background-glare-image"> </div>
</div>
<div id="art-main">
    <div class="cleared reset-box"></div>
<div class="art-nav">
	<div class="art-nav-l"></div>
	<div class="art-nav-r"></div>
<div class="art-nav-outer">
<div class="art-nav-wrapper">
<div class="art-nav-inner">
			<ul class="art-hmenu"><li id="current" class="active item101"><a class=" active" href="/cms/joomla17/"><span class="l"></span><span class="r"></span><span class="t">Home</span></a></li><li class="item116"><a href="/cms/joomla17/index.php/online-cv"><span class="l"></span><span class="r"></span><span class="t">Online CV</span></a></li><li class="item119"><a href="/cms/joomla17/index.php/projects"><span class="l"></span><span class="r"></span><span class="t">Projects</span></a><ul><li class="item120"><a href="/cms/joomla17/index.php/projects/commercial-titles">Commercial Titles</a></li><li class="item121"><a href="/cms/joomla17/index.php/projects/personal-works">Personal Works</a></li></ul></li><li class="item135"><a href="/cms/joomla17/index.php/developerblog"><span class="l"></span><span class="r"></span><span class="t">DeveloperBlog</span></a></li><li class="item118"><a href="/cms/joomla17/index.php/lifeblog"><span class="l"></span><span class="r"></span><span class="t">LifeBlog</span></a></li><li class="item133"><a href="/cms/joomla17/index.php/about"><span class="l"></span><span class="r"></span><span class="t">About</span></a></li></ul></div>
</div>
</div>
</div>
<div class="cleared reset-box"></div>
<div class="art-sheet">
    <div class="art-sheet-body">
<div class="art-header">
    <div class="art-header-clip">
    <div class="art-header-center">
        <div class="art-header-png"></div>
    </div>
    </div>
<div class="art-logo">
 <h1 class="art-logo-name"><a href="/cms/joomla17/">Example Online Portfolio - AikDev.co.uk 2012</a></h1>
</div>

</div>
<div class="cleared reset-box"></div>
<table class="position" cellpadding="0" cellspacing="0" border="0"><tr valign="top"><td width="33%">        <div class="art-block">
            <div class="art-block-body">
        
                <div class="art-blockheader">
            <div class="l"></div>
            <div class="r"></div>
            <h3 class="t">
        Random Images Ex</h3>
        </div>
                <div class="art-blockcontent">
            <div class="art-blockcontent-body">
        
        <!-- RIE - Random Image Extended for Joomla 1.7 by Kubik-Rubik.de - Viktor Vogel --><div class="random_image_extended">
            <a href="/cms/joomla17/../../resources/random_img/rtw_myworld001.jpg" title="rtw_myworld001" rel="shadowbox[random]">
        <img src="/cms/joomla17/../../resources/random_img/thumbs/rtw_myworld001.jpg" alt="rtw_myworld001.jpg" width="180" height="180" />    </a>
                        <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/awards001.jpg" title="awards001"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/music0009.jpg" title="music0009"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/music0002.jpg" title="music0002"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/ubi_dsf001.jpg" title="ubi_dsf001"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/dare07.jpg" title="dare07"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/awards004.jpg" title="awards004"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/ubi_dsf002.jpg" title="ubi_dsf002"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/music0001.jpg" title="music0001"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/awards003.jpg" title="awards003"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/dscn0077.jpg" title="dscn0077"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/music0011.jpg" title="music0011"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/ubi_grfs001.jpg" title="ubi_grfs001"></a>
                                <a rel="shadowbox[random]" href="/cms/joomla17/../../resources/random_img/awards002.jpg" title="awards002"></a>
            </div>
        
        		<div class="cleared"></div>
            </div>
        </div>
        
        
        		<div class="cleared"></div>
            </div>
        </div>
        
</td><td width="33%">        <div class="art-block">
            <div class="art-block-body">
        
                <div class="art-blockheader">
            <div class="l"></div>
            <div class="r"></div>
            <h3 class="t">
        Recently updated articles</h3>
        </div>
                <div class="art-blockcontent">
            <div class="art-blockcontent-body">
        
        <ul class="latestnews">
	<li>
		<a href="/cms/joomla17/index.php/projects/commercial-titles/114-201x-ubisoft-the-crew">
			[201x] Ubisoft, The CREW</a>
	</li>
	<li>
		<a href="/cms/joomla17/index.php/lifeblog/113-songbook-kashiwagi-yuki-shortcake">
			Songbook: Kashiwagi Yuki – Shortcake</a>
	</li>
	<li>
		<a href="/cms/joomla17/index.php/projects/commercial-titles/112-2013-creative-assembly-rome-2">
			[2013] Creative Assembly, ROME 2 </a>
	</li>
	<li>
		<a href="/cms/joomla17/index.php/projects/commercial-titles/111-201x-ubisoft-watch-dogs">
			[201x] Ubisoft, Watch Dogs </a>
	</li>
	<li>
		<a href="/cms/joomla17/index.php/projects/personal-works/110-fxcomposer-scrapbook-2011">
			FXComposer ScrapBook (2011)</a>
	</li>
	<li>
		<a href="/cms/joomla17/index.php/developerblog/109-a-very-funny-spoof-of-driversf">
			A very funny spoof of Driver:SF </a>
	</li>
	<li>
		<a href="/cms/joomla17/index.php/developerblog/108-dancing-for-just-dance-due-to-the-world-dance-day">
			Dancing for Just Dance due to the World Dance Day</a>
	</li>
	<li>
		<a href="/cms/joomla17/index.php/lifeblog/107-manga-slam-dunk">
			Manga: Slam Dunk</a>
	</li>
</ul>

        
        		<div class="cleared"></div>
            </div>
        </div>
        
        
        		<div class="cleared"></div>
            </div>
        </div>
        
</td><td width="34%">        <div class="art-block">
            <div class="art-block-body">
        
                <div class="art-blockheader">
            <div class="l"></div>
            <div class="r"></div>
            <h3 class="t">
        Searchbox</h3>
        </div>
                <div class="art-blockcontent">
            <div class="art-blockcontent-body">
        
        <form action="/cms/joomla17/index.php" method="post">
	<div class="search">
		<label for="mod-search-searchword">Search...</label><input name="searchword" id="mod-search-searchword" maxlength="20"  class="inputbox" type="text" size="20" value="Search..."  onblur="if (this.value=='') this.value='Search...';" onfocus="if (this.value=='Search...') this.value='';" /><span class="art-button-wrapper"><span class="art-button-l"> </span><span class="art-button-r"> </span><input type="submit" value="Search" class="button art-button" onclick="this.form.searchword.focus();" /></span>	<input type="hidden" name="task" value="search" />
	<input type="hidden" name="option" value="com_search" />
	<input type="hidden" name="Itemid" value="101" />
	</div>
</form>

        
        		<div class="cleared"></div>
            </div>
        </div>
        
        
        		<div class="cleared"></div>
            </div>
        </div>
        
</td></tr></table><div class="art-content-layout">
    <div class="art-content-layout-row">
<div class="art-layout-cell art-content">

<div class="art-post">
    <div class="art-post-body">
<div class="art-post-inner">
<div class="art-postcontent">
<!------------------------------------- THE CONTENT ------------------------------------------------->
<div id="lofass32" class="lof-ass" style="height:auto; width:auto">
<div class="lofass-container  lof-css3  lof-snright">
    
        <div class="preload"><div></div></div>
         <!-- MAIN CONTENT --> 
      <div class="lof-main-wapper" style="height:315px;width:560px;">
                      <div class="lof-main-item ">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-ubi_dsf001.jpg" title="[2009] Ubisoft, Driver: San Francisco" width="560" alt="[2009] Ubisoft, Driver: San Francisco" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="[2009] Ubisoft, Driver: San Francisco" href="/cms/joomla17/index.php/projects/commercial-titles/86-2009-ubisoft-driver-san-francisco">[2009] Ubisoft, Driver: San Francisco</a></h4>
                                        <p>
	

	I have joined the Driver project in 2009, as a rendering/graphic programmer.

	Roles...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt12_cgame002.jpg" title="Y1S2 C TextGame" width="560" alt="Y1S2 C TextGame" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Y1S2 C TextGame" href="/cms/joomla17/index.php/projects/personal-works/7-y1s2-c-textgame">Y1S2 C TextGame</a></h4>
                                        <p>
	

	Star Surfer, The game is developed in 2005 on a basic console using C language. I make...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://www.gamersyde.com/news_e3_the_crew_gameplay-14202.jpg" title="[201x] Ubisoft, The CREW" width="560" alt="[201x] Ubisoft, The CREW" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="[201x] Ubisoft, The CREW" href="/cms/joomla17/index.php/projects/commercial-titles/114-201x-ubisoft-the-crew">[201x] Ubisoft, The CREW</a></h4>
                                        <p>
	

	The Crew was present and correct at Ubisoft&#39;s E3 conference 2013. It&#39;s an...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt32_terrain007.jpg" title="Procedural Generation (2008)" width="560" alt="Procedural Generation (2008)" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Procedural Generation (2008)" href="/cms/joomla17/index.php/projects/personal-works/32-procedural-generation-2008">Procedural Generation (2008)</a></h4>
                                        <p>
	

	The project shows terrain generation techniques, and how to implement them together to...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt12_gba005.jpg" title="Y1S2 GBA Alien" width="560" alt="Y1S2 GBA Alien" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Y1S2 GBA Alien" href="/cms/joomla17/index.php/projects/personal-works/10-y1s2-gba-alien">Y1S2 GBA Alien</a></h4>
                                        <p>
	

	Alien, a simple platformer developed on Game boy advance. I&#39;ve got the idea from...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt22_ps2doom006.jpg" title="Y2S2 PS2 EECore" width="560" alt="Y2S2 PS2 EECore" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Y2S2 PS2 EECore" href="/cms/joomla17/index.php/projects/personal-works/6-y2s2-ps2-eecore">Y2S2 PS2 EECore</a></h4>
                                        <p>
	

	SCEE Award Winner 2006

	Developed on the Playstation 2, The project is created base on...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-ubi_grfs001.jpg" title="[2011] Ubisoft, GhostRecon : Future Soldier" width="560" alt="[2011] Ubisoft, GhostRecon : Future Soldier" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="[2011] Ubisoft, GhostRecon : Future Soldier" href="/cms/joomla17/index.php/projects/commercial-titles/98-2011-ubisoft-ghostreconfuturesoldier">[2011] Ubisoft, GhostRecon : Future Soldier</a></h4>
                                        <p>
	

	Ghost Recon: Future Soldier. I joined the team to help optimizing and polishing the PS3...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-old_eq001.png" title="Equilibrium (2010)" width="560" alt="Equilibrium (2010)" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Equilibrium (2010)" href="/cms/joomla17/index.php/projects/personal-works/101-equilibrium-2010">Equilibrium (2010)</a></h4>
                                        <p>
	

	Equilibrium is an RTS game building for a mobile platform. I have worked on this small...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt11_fgame003.jpg" title="Y1S1 FlashGame" width="560" alt="Y1S1 FlashGame" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Y1S1 FlashGame" href="/cms/joomla17/index.php/projects/personal-works/4-y1s1-flashgame">Y1S1 FlashGame</a></h4>
                                        <p>
	

	Dream Quest, the game I have developed in 2005 using Flash actionscript. It&#39;s a...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt21_astar004.jpg" title="Y2S1 Pathfinding" width="560" alt="Y2S1 Pathfinding" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Y2S1 Pathfinding" href="/cms/joomla17/index.php/projects/personal-works/12-y2s1-pathfinding">Y2S1 Pathfinding</a></h4>
                                        <p>
	

	PathFinding Algorithm is developed in 2006. These small applications are my work from the...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt31_tool001.jpg" title="Ogre3D Scene Manipulator (2007)" width="560" alt="Ogre3D Scene Manipulator (2007)" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Ogre3D Scene Manipulator (2007)" href="/cms/joomla17/index.php/projects/personal-works/64-ogre3d-scene-manipulator-2007">Ogre3D Scene Manipulator (2007)</a></h4>
                                        <p>
	

	The demo is developed in 2007 as parted of my course works for &quot;Game Tools...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt32_ogre017.jpg" title="Project CEPA (2008)" width="560" alt="Project CEPA (2008)" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Project CEPA (2008)" href="/cms/joomla17/index.php/projects/personal-works/29-y3s2-group-project">Project CEPA (2008)</a></h4>
                                        <p>
	

	Editor pick! : Project of the Year Award 

	CEPA Project is a full game project from a...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt11_banner001.jpg" title="Y1S1 FlashBanner" width="560" alt="Y1S1 FlashBanner" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Y1S1 FlashBanner" href="/cms/joomla17/index.php/projects/personal-works/3-y1s1-flashbanner">Y1S1 FlashBanner</a></h4>
                                        <p>
	

	This is my first coursework at Abertay. It does look like an introductory more than a...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt31_ps2vu001.jpg" title="Y3S1 PS2 VectorUnits" width="560" alt="Y3S1 PS2 VectorUnits" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Y3S1 PS2 VectorUnits" href="/cms/joomla17/index.php/projects/personal-works/27-y3s1-ps2-vectorunits">Y3S1 PS2 VectorUnits</a></h4>
                                        <p>
	

	The program has been developed in 2007, in order to explore and experiment the real power...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt22_ogl002.jpg" title="Y2S2 OpenGL" width="560" alt="Y2S2 OpenGL" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Y2S2 OpenGL" href="/cms/joomla17/index.php/projects/personal-works/15-y2s2-opengl">Y2S2 OpenGL</a></h4>
                                        <p>
	

	Developed in 2006, the application is part of my 3D programming practice using OpenGL...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt42_final002.jpg" title="Character Instancing (2009)" width="560" alt="Character Instancing (2009)" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Character Instancing (2009)" href="/cms/joomla17/index.php/projects/personal-works/61-character-instancing-2009">Character Instancing (2009)</a></h4>
                                        <p>
	

	Editor pick!: Project of the Year

	The research has been carried on during my Honours...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://farm9.staticflickr.com/8413/8981193561_b78147297d.jpg" title="[2013] Creative Assembly, ROME 2 " width="560" alt="[2013] Creative Assembly, ROME 2 " > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="[2013] Creative Assembly, ROME 2 " href="/cms/joomla17/index.php/projects/commercial-titles/112-2013-creative-assembly-rome-2">[2013] Creative Assembly, ROME 2 </a></h4>
                                        <p>
	

	Total War: ROME 2
	Like previous &quot;Total War&quot; games, &quot;Total War: Rome...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt21_wingdi005.jpg" title="Y2S1 Windows Programming" width="560" alt="Y2S1 Windows Programming" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Y2S1 Windows Programming" href="/cms/joomla17/index.php/projects/personal-works/9-y2s1-windows-programming">Y2S1 Windows Programming</a></h4>
                                        <p>
	

	Based on sprites from Dragonball Z and Gundam Wing. This is my 2D Fighting game developed...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-cgt41_bezier002.jpg" title="Bezier Curves Animation Control(2008)" width="560" alt="Bezier Curves Animation Control(2008)" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="Bezier Curves Animation Control(2008)" href="/cms/joomla17/index.php/projects/personal-works/13-bezier-curves-animation-control2008">Bezier Curves Animation Control(2008)</a></h4>
                                        <p>
	

	The demo shows the Piecewise-Bezier Curve animation control system. Users can adjust the...</p>
                                     </div>
                                              </div> 
                        <div class="lof-main-item">
                                   <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/560x315-rtw_myworld001.jpg" title="[2008] RTW 'Project: My World'" width="560" alt="[2008] RTW 'Project: My World'" > 
                 
                     
                 <div class="lof-description">
                    <h4><a target="_parent" title="[2008] RTW 'Project: My World'" href="/cms/joomla17/index.php/projects/commercial-titles/45-2008-rtw-project-my-world">[2008] RTW 'Project: My World'</a></h4>
                                        <p>
	

	Even this is my third job as a software developer. However, it&#39;s still very exciting...</p>
                                     </div>
                                              </div> 
                    
      </div>
      <!-- END MAIN CONTENT --> 
        <!-- NAVIGATOR -->
                  
              <div class="lof-navigator-outer">
                    <ul class="lof-navigator">
                                            <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-ubi_dsf001.jpg" title="[2009] Ubisoft, Driver: San Francisco" width="60" alt="[2009] Ubisoft, Driver: San Francisco" > 
                                                                                                  <h4>[2009] Ubisoft, Driver: San Francisco</h4>
                                                                                                <span>Thursday, 01 July 2010 09:03</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt12_cgame002.jpg" title="Y1S2 C TextGame" width="60" alt="Y1S2 C TextGame" > 
                                                                                                  <h4>Y1S2 C TextGame</h4>
                                                                                                <span>Monday, 30 June 2008 18:29</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://www.gamersyde.com/news_e3_the_crew_gameplay-14202.jpg" title="[201x] Ubisoft, The CREW" width="60" alt="[201x] Ubisoft, The CREW" > 
                                                                                                  <h4>[201x] Ubisoft, The CREW</h4>
                                                                                                <span>Thursday, 13 June 2013 07:55</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt32_terrain007.jpg" title="Procedural Generation (2008)" width="60" alt="Procedural Generation (2008)" > 
                                                                                                  <h4>Procedural Generation (2008)</h4>
                                                                                                <span>Friday, 01 August 2008 21:00</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt12_gba005.jpg" title="Y1S2 GBA Alien" width="60" alt="Y1S2 GBA Alien" > 
                                                                                                  <h4>Y1S2 GBA Alien</h4>
                                                                                                <span>Monday, 14 July 2008 21:38</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt22_ps2doom006.jpg" title="Y2S2 PS2 EECore" width="60" alt="Y2S2 PS2 EECore" > 
                                                                                                  <h4>Y2S2 PS2 EECore</h4>
                                                                                                <span>Thursday, 17 July 2008 21:00</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-ubi_grfs001.jpg" title="[2011] Ubisoft, GhostRecon : Future Soldier" width="60" alt="[2011] Ubisoft, GhostRecon : Future Soldier" > 
                                                                                                  <h4>[2011] Ubisoft, GhostRecon : Future Soldier</h4>
                                                                                                <span>Monday, 09 January 2012 07:30</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-old_eq001.png" title="Equilibrium (2010)" width="60" alt="Equilibrium (2010)" > 
                                                                                                  <h4>Equilibrium (2010)</h4>
                                                                                                <span>Friday, 13 January 2012 19:33</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt11_fgame003.jpg" title="Y1S1 FlashGame" width="60" alt="Y1S1 FlashGame" > 
                                                                                                  <h4>Y1S1 FlashGame</h4>
                                                                                                <span>Sunday, 29 June 2008 20:40</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt21_astar004.jpg" title="Y2S1 Pathfinding" width="60" alt="Y2S1 Pathfinding" > 
                                                                                                  <h4>Y2S1 Pathfinding</h4>
                                                                                                <span>Wednesday, 16 July 2008 23:22</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt31_tool001.jpg" title="Ogre3D Scene Manipulator (2007)" width="60" alt="Ogre3D Scene Manipulator (2007)" > 
                                                                                                  <h4>Ogre3D Scene Manipulator (2007)</h4>
                                                                                                <span>Friday, 01 August 2008 21:00</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt32_ogre017.jpg" title="Project CEPA (2008)" width="60" alt="Project CEPA (2008)" > 
                                                                                                  <h4>Project CEPA (2008)</h4>
                                                                                                <span>Friday, 01 August 2008 21:00</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt11_banner001.jpg" title="Y1S1 FlashBanner" width="60" alt="Y1S1 FlashBanner" > 
                                                                                                  <h4>Y1S1 FlashBanner</h4>
                                                                                                <span>Sunday, 29 June 2008 14:27</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt31_ps2vu001.jpg" title="Y3S1 PS2 VectorUnits" width="60" alt="Y3S1 PS2 VectorUnits" > 
                                                                                                  <h4>Y3S1 PS2 VectorUnits</h4>
                                                                                                <span>Friday, 01 August 2008 21:00</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt22_ogl002.jpg" title="Y2S2 OpenGL" width="60" alt="Y2S2 OpenGL" > 
                                                                                                  <h4>Y2S2 OpenGL</h4>
                                                                                                <span>Friday, 18 July 2008 08:17</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt42_final002.jpg" title="Character Instancing (2009)" width="60" alt="Character Instancing (2009)" > 
                                                                                                  <h4>Character Instancing (2009)</h4>
                                                                                                <span>Friday, 20 March 2009 00:00</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://farm9.staticflickr.com/8413/8981193561_b78147297d.jpg" title="[2013] Creative Assembly, ROME 2 " width="60" alt="[2013] Creative Assembly, ROME 2 " > 
                                                                                                  <h4>[2013] Creative Assembly, ROME 2 </h4>
                                                                                                <span>Sunday, 03 March 2013 14:51</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt21_wingdi005.jpg" title="Y2S1 Windows Programming" width="60" alt="Y2S1 Windows Programming" > 
                                                                                                  <h4>Y2S1 Windows Programming</h4>
                                                                                                <span>Monday, 14 July 2008 22:11</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-cgt41_bezier002.jpg" title="Bezier Curves Animation Control(2008)" width="60" alt="Bezier Curves Animation Control(2008)" > 
                                                                                                  <h4>Bezier Curves Animation Control(2008)</h4>
                                                                                                <span>Friday, 01 August 2008 21:00</span>
                                                                                            </div>    
                        </li>
                                             <li>
                            <div>
                                                                 <img src="http://my-site:5000/cms/joomla17/cache/lofthumbs/60x60-rtw_myworld001.jpg" title="[2008] RTW 'Project: My World'" width="60" alt="[2008] RTW 'Project: My World'" > 
                                                                                                  <h4>[2008] RTW 'Project: My World'</h4>
                                                                                                <span>Friday, 01 August 2008 21:00</span>
                                                                                            </div>    
                        </li>
                          
                    </ul>
              </div>
              
  </div>
 </div> <script type="text/javascript">

  var _lofmain =  $('lofass32'); 
  	if( _lofmain.getElements(".lof-description") ){
		_lofmain.getElements(".lof-description").setStyle("opacity", 0.5);
	}
    
  var object = new LofSlideshow( _lofmain,
                  { 
                    fxObject:{
                    transition:Fx.Transitions.Quad.easeInOut,  
                    duration:500                    },
                    startItem:0,
                    interval:5000,
                    direction :'hrleft', 
                    navItemHeight:90,
                    navItemWidth:300,
                    navItemsDisplay:4,
                    navPos:'right'
                  } );
      object.start( 1, _lofmain.getElement('.preload') );

</script>


</div>
<div class="cleared"></div>
</div>

		<div class="cleared"></div>
    </div>
</div>
<div class="blog-featured"></div>
  <div class="cleared"></div>
</div>

    </div>
</div>
<div class="cleared"></div>


        <div class="art-block">
            <div class="art-block-body">
        
                <div class="art-blockheader">
            <div class="l"></div>
            <div class="r"></div>
            <h3 class="t">
        Features: BestView in Firefox/Chrome</h3>
        </div>
                <div class="art-blockcontent">
            <div class="art-blockcontent-body">
        
        

<ul class="featcats">
	        <li class="featcat col1 firstcol" style="width:30%">
        <h5><a href="/cms/joomla17/index.php/developerblog">DeveloperBlog</a></h5>                    	<ul class="featcats_leading">
			        		<li><h5>
				                <a class="mod_featcats-title" href="/cms/joomla17/index.php/developerblog/109-a-very-funny-spoof-of-driversf">
                A very funny spoof of Driver:SF                 </a>
                                </h5>								                <p>From GameTrailer, share this from my friend&#39;s FB today&hellip;</p>
				                </li>
                    		<li><h5>
				                <a class="mod_featcats-title" href="/cms/joomla17/index.php/developerblog/108-dancing-for-just-dance-due-to-the-world-dance-day">
                Dancing for Just Dance due to the World Dance Day                </a>
                                </h5>								                <p>Regarding to the World Dance Day (29th April) 
 
	Since we, Reflections, are the developers behind&hellip;</p>
				                </li>
                    		<li><h5>
				                <a class="mod_featcats-title" href="/cms/joomla17/index.php/developerblog/17-c-faqs-notes-and-snippets">
                C++ Faqs, Notes and Snippets                </a>
                                </h5>								                <p>The collection of C++ questions, notes and snippets&hellip;</p>
				                </li>
                        </ul>
                        
                </li>
            <li class="featcat col2" style="width:30%">
        <h5><a href="/cms/joomla17/index.php/lifeblog">LifeBlog</a></h5>                    	<ul class="featcats_leading">
			        		<li><h5>
				                <a class="mod_featcats-title" href="/cms/joomla17/index.php/lifeblog/113-songbook-kashiwagi-yuki-shortcake">
                Songbook: Kashiwagi Yuki – Shortcake                </a>
                                </h5>								                <p>[Songbook] is a collection of some of my favorite, nicely touch piece of music where I try to transc&hellip;</p>
				                </li>
                    		<li><h5>
				                <a class="mod_featcats-title" href="/cms/joomla17/index.php/lifeblog/107-manga-slam-dunk">
                Manga: Slam Dunk                </a>
                                </h5>								                <p>Today I would love to share the story about one of my favorite manga&nbsp;&hellip;</p>
				                </li>
                    		<li><h5>
				                <a class="mod_featcats-title" href="/cms/joomla17/index.php/lifeblog/94-film-be-with-you-2004">
                Film: Be with You (2004)                </a>
                                </h5>								                <p>In my opinion, &quot;Ima, Ai ni Yukimasu&quot; (Be with You), is definitely one of the best Japanese drama fil&hellip;</p>
				                </li>
                        </ul>
                        
                </li>
            <li class="featcat col3 lastcol" style="width:30%">
        <h5><a href="/cms/joomla17/index.php/projects">Projects</a></h5>                    	<ul class="featcats_leading">
			        		<li><h5>
				                <a class="mod_featcats-title" href="/cms/joomla17/index.php/projects/commercial-titles/98-2011-ubisoft-ghostreconfuturesoldier">
                [2011] Ubisoft, GhostRecon : Future Soldier                </a>
                                </h5>								                <p>Ghost Recon: Future Soldier. I joined the team to help optimizing and polishing the PS3 version of t&hellip;</p>
				                </li>
                    		<li><h5>
				                <a class="mod_featcats-title" href="/cms/joomla17/index.php/projects/commercial-titles/112-2013-creative-assembly-rome-2">
                [2013] Creative Assembly, ROME 2                 </a>
                                </h5>								                <p>Total War: ROME 2
	Like previous &quot;Total War&quot; games, &quot;Total War: Rome 2&quot; revolves around massive mil&hellip;</p>
				                </li>
                    		<li><h5>
				                <a class="mod_featcats-title" href="/cms/joomla17/index.php/projects/commercial-titles/114-201x-ubisoft-the-crew">
                [201x] Ubisoft, The CREW                </a>
                                </h5>								                <p>The Crew was present and correct at Ubisoft&#39;s E3 conference 2013. It&#39;s an open-world racer from Ubis&hellip;</p>
				                </li>
                        </ul>
                        
                </li>
    </ul>

        
        		<div class="cleared"></div>
            </div>
        </div>
        
        
        		<div class="cleared"></div>
            </div>
        </div>
        
<div class="art-footer">
    <div class="art-footer-t"></div>
    <div class="art-footer-b"></div>
    <div class="art-footer-body">
                        <div class="art-footer-text">
                                        <p><a href="#">Link1</a> | <a href="#">Link2</a> | <a href="#">Link3</a></p><p>Copyright © 2012. All Rights Reserved.</p>

                                                        </div>
        <div class="cleared"></div>
    </div>
</div>

		<div class="cleared"></div>
    </div>
</div>
<div class="cleared"></div>
<p class="art-page-footer"><a href="http://www.artisteer.com/?p=joomla_templates">Joomla template</a> created with Artisteer.</p>

    <div class="cleared"></div>
</div>
</div>

</body>
</html>